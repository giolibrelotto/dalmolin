                <div class="col-md-12 col-sm-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <center><b>2021</b></center>
                        </div>
                        <div class="panel-body">
                            <ul class="nav nav-tabs">
                                <li class="active"><a href="#Jan2021" data-toggle="tab">Janeiro</a>
                                </li>
                                <li class=""><a href="#Fev2021" data-toggle="tab">Fevereiro</a>
                                </li>
                                <li class=""><a href="#Mar2021" data-toggle="tab">Março</a>
                                </li>
                                <li class=""><a href="#Abr2021" data-toggle="tab">Abril</a>
                                </li>
                                <li class=""><a href="#Mai2021" data-toggle="tab">Maio</a>
                                </li>
                                <li class=""><a href="#Jun2021" data-toggle="tab">Junho</a>
                                </li>
                                <li class=""><a href="#Jul2021" data-toggle="tab">Julho</a>
                                </li>
                                <li class=""><a href="#Ago2021" data-toggle="tab">Agosto</a>
                                </li>
                                <li class=""><a href="#Set2021" data-toggle="tab">Setembro</a>
                                </li>
                                <li class=""><a href="#Out2021" data-toggle="tab">Outubro</a>
                                </li>
                                <li class=""><a href="#Nov2021" data-toggle="tab">Novembro</a>
                                </li>
                                <li class=""><a href="#Dez2021" data-toggle="tab">Dezembro</a>
                                </li>
                            </ul>

                            <div class="tab-content">
                                <div class="tab-pane fade active in" id="Jan2021">
                                    <?php table_month('SpedEFD-88579701000178-0650024230-Remessa de arquivo original-jan2021.txt'); ?>
                                </div>
                                <div class="tab-pane fade" id="Fev2021">
                                    <?php table_month('SpedEFD-88579701000178-0650024230-Remessa de arquivo original-fev2021.txt'); ?>
                                </div>
                                <div class="tab-pane fade" id="Mar2021">
                                    <?php table_month('SpedEFD-88579701000178-0650024230-Remessa de arquivo original-mar2021.txt'); ?>
                                </div>
                                <div class="tab-pane fade" id="Abr2021">
                                    <?php table_month('SpedEFD-88579701000178-0650024230-Remessa de arquivo original-abr2021.txt'); ?>
                                </div>
                                <div class="tab-pane fade" id="Mai2021">
                                    <?php table_month('SpedEFD-88579701000178-0650024230-Remessa de arquivo original-mai2021.txt'); ?>
                                echo '</div>
                                <div class="tab-pane fade" id="Jun2021">
                                    <?php table_month('SpedEFD-88579701000178-0650024230-Remessa de arquivo original-jun2021.txt'); ?>
                                </div>
                                <div class="tab-pane fade" id="Jul2021">
                                    <?php table_month('SpedEFD-88579701000178-0650024230-Remessa de arquivo original-jul2021.txt'); ?>
                                </div>
                                <div class="tab-pane fade" id="Ago2021">
                                    <?php table_month('SpedEFD-88579701000178-0650024230-Remessa de arquivo original-ago2021.txt'); ?>
                                </div>
                                <div class="tab-pane fade" id="Set2021">
                                    <?php table_month('SpedEFD-88579701000178-0650024230-Remessa de arquivo original-set2021.txt'); ?>
                                </div>
                                <div class="tab-pane fade" id="Out2021">
                                    <?php table_month('SpedEFD-88579701000178-0650024230-Remessa de arquivo original-out2021.txt'); ?>
                                </div>
                                <div class="tab-pane fade" id="Nov2021">
                                    <?php table_month('SpedEFD-88579701000178-0650024230-Remessa de arquivo original-nov2021.txt'); ?>
                                </div>
                                <div class="tab-pane fade" id="Dez2021">
                                    <?php table_month('SpedEFD-88579701000178-0650024230-Remessa de arquivo original-dez2021.txt'); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

