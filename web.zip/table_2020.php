                <!--div class="row"-->
                <div class="col-md-12 col-sm-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <center><b>2020</b></center>
                        </div>
                        <div class="panel-body">
                            <ul class="nav nav-tabs">
                                <li class="active"><a href="#Jan" data-toggle="tab">Janeiro</a>
                                </li>
                                <li class=""><a href="#Fev" data-toggle="tab">Fevereiro</a>
                                </li>
                                <li class=""><a href="#Mar" data-toggle="tab">Março</a>
                                </li>
                                <li class=""><a href="#Abr" data-toggle="tab">Abril</a>
                                </li>
                                <li class=""><a href="#Mai" data-toggle="tab">Maio</a>
                                </li>
                                <li class=""><a href="#Jun" data-toggle="tab">Junho</a>
                                </li>
                                <li class=""><a href="#Jul" data-toggle="tab">Julho</a>
                                </li>
                                <li class=""><a href="#Ago" data-toggle="tab">Agosto</a>
                                </li>
                                <li class=""><a href="#Set" data-toggle="tab">Setembro</a>
                                </li>
                                <li class=""><a href="#Out" data-toggle="tab">Outubro</a>
                                </li>
                                <li class=""><a href="#Nov" data-toggle="tab">Novembro</a>
                                </li>
                                <li class=""><a href="#Dez" data-toggle="tab">Dezembro</a>
                                </li>
                            </ul>

                            <div class="tab-content">
                                <div class="tab-pane fade active in" id="Jan">
                                    <?php table_month('SpedEFD-88579701000178-0650024230-Remessa de arquivo original-jan2020.txt'); ?>
                                </div>
                                <div class="tab-pane fade" id="Fev">
                                    <?php table_month('SpedEFD-88579701000178-0650024230-Remessa de arquivo original-fev2020.txt'); ?>
                                </div>
                                <div class="tab-pane fade" id="Mar">
                                    <?php table_month('SpedEFD-88579701000178-0650024230-Remessa de arquivo original-mar2020.txt'); ?>
                                </div>
                                <div class="tab-pane fade" id="Abr">
                                    <?php table_month('SpedEFD-88579701000178-0650024230-Remessa de arquivo original-abr2020.txt'); ?>
                                </div>
                                <div class="tab-pane fade" id="Mai">
                                    <?php table_month('SpedEFD-88579701000178-0650024230-Remessa de arquivo original-mai2020.txt'); ?>
                                </div>
                                <div class="tab-pane fade" id="Jun">
                                    <?php table_month('SpedEFD-88579701000178-0650024230-Remessa de arquivo original-jun2020.txt'); ?>
                                </div>
                                <div class="tab-pane fade" id="Jul">
                                    <?php table_month('SpedEFD-88579701000178-0650024230-Remessa de arquivo original-jul2020.txt'); ?>
                                </div>
                                <div class="tab-pane fade" id="Ago">
                                    <?php table_month('SpedEFD-88579701000178-0650024230-Remessa de arquivo original-ago2020.txt'); ?>
                                </div>
                                <div class="tab-pane fade" id="Set">
                                    <?php table_month('SpedEFD-88579701000178-0650024230-Remessa de arquivo original-set2020.txt'); ?>
                                </div>
                                <div class="tab-pane fade" id="Out">
                                    <?php table_month('SpedEFD-88579701000178-0650024230-Remessa de arquivo original-out2020.txt'); ?>
                                </div>
                                <div class="tab-pane fade" id="Nov">
                                    <?php table_month('SpedEFD-88579701000178-0650024230-Remessa de arquivo original-nov2020.txt'); ?>
                                </div>
                                <div class="tab-pane fade" id="Dez">
                                    <?php table_month('SpedEFD-88579701000178-0650024230-Remessa de arquivo original-dez2020.txt'); ?>
                                </div>
                            </div>
                        </div>
                    </div>
